using System.Windows.Controls;

namespace MusicClient.Views
{
    /// <summary>
    /// Interaction logic for UploadTrackView.xaml
    /// </summary>
    public partial class UploadTrackView : UserControl
    {
        public UploadTrackView()
        {
            InitializeComponent();
        }
    }
} 