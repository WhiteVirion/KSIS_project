using System.Windows.Controls;

namespace MusicClient.Views
{
    public partial class FavoritesView : UserControl
    {
        public FavoritesView()
        {
            InitializeComponent();
        }
    }
} 