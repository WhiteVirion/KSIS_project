using System.Windows.Controls;

namespace MusicClient.Views
{
    public partial class EmptyView : UserControl
    {
        public EmptyView()
        {
            InitializeComponent();
        }
    }
} 