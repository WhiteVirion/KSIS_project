using System.Windows.Controls;

namespace MusicClient.Views
{
    public partial class AllTracksView : UserControl
    {
        public AllTracksView()
        {
            InitializeComponent();
        }
    }
} 