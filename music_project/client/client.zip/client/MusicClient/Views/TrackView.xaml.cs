using System.Windows.Controls;

namespace MusicClient.Views
{
    public partial class TrackView : UserControl
    {
        public TrackView()
        {
            InitializeComponent();
        }
    }
} 