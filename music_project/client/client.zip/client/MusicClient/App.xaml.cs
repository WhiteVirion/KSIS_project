using System;
using System.Windows;

namespace MusicClient
{
    public partial class App : Application
    {
    }
}
