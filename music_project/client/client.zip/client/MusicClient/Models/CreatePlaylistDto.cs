namespace MusicClient.Models
{
    public class CreatePlaylistDto
    {
        public string Name { get; set; }
    }
} 