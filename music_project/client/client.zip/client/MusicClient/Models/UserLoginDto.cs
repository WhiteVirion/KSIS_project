namespace MusicClient.Models
{
    public class UserLoginDto
    {
        public string Nickname { get; set; }
        public string Password { get; set; }
    }
} 