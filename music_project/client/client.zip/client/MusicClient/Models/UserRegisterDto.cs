namespace MusicClient.Models
{
    public class UserRegisterDto
    {
        public string Nickname { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }
} 